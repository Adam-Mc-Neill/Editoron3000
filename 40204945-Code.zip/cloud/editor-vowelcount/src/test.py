import unittest
from flask import Flask
from app import app
from app import vowelcnt
from vowelcount import vowelcount


class testVowelCount(unittest.TestCase):

    def test_vowelcount(self):
        self.assertEqual(vowelcount("good"),2)

    def test_novowels(self):
        self.assertEqual(vowelcount("nvwls"),0)

    def test_RejectsMissingParams(self):
        tester = app.test_client(self)
        response = tester.get('/', content_type='html/text')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data, b'{"error": true, "status": 400, "message": "You must provide a string"}')
 

    def test_VowelCountRequest(self):
        tester = app.test_client(self)
        response = tester.get('/?x=test', content_type='html/text')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"error": false, "status": 200, "string": "test contains 1 vowels.", "x": "test", "answer": 1}')

if __name__ == 'main':
    unittest.main()
