from flask import Flask
from flask import request
from flask import Response
import json

import vowelcount

app = Flask(__name__)

@app.route('/')
def vowelcnt():
  x = request.args.get("x")
  if x is None:
    msg = "You must provide a string"
    jsonErrorRes = {
      "error": True, 
      "status": 400, 
      "message": msg
    }
    reply = json.dumps(jsonErrorRes)
    response=Response(response=reply, status=400, mimetype='application/json')
    response.headers["Content-Type"]="application/json"
    response.headers["Access-Control-Allow-Origin"]="*"
    return response
  answer = vowelcount.vowelcount(x)
  jsonRes = {
      "error": False,
      "status": 200,
      "string": x+" contains " + str(answer) + " vowels.",
      "x": x,
      "answer":answer
    }

  reply = json.dumps(jsonRes)
  response=Response(response=reply, status=200, mimetype='application/json')
  response.headers["Content-Type"]="application/json"
  response.headers["Access-Control-Allow-Origin"]="*"

  return response

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5000)
