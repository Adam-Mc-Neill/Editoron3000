import helpers

def VowelCount():
    response = helpers.getJsonFromURL(helpers.fetchURL('vowelcount', 'test,%20test'))
    expected = '{"error": false, "status": 200, "string": "test, test contains 2 vowels.", "x": "test, test", "answer": 2}'
    if(expected != response):
        return "Failure"
    return "Success"

def TheReplacer():
    response = helpers.getJsonFromURL(helpers.fetchURL('thereplacer', 'test,%20the%20test'))
    expected = '{"error": false, "status": 200, "answer": "test, a test", "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}}'
    if(expected != response):
        return ("Failure, response was: " + response)
    return "Success"

    
def CommaCount():
    response = helpers.getJsonFromURL(helpers.fetchURL('commacount', 'test,%20test'))
    expected = '{"Answer": 1, "Error": false, "Status": 200, "Message": "1 commas in test, test"}'
    if(expected != response):
        return ("Failure, response was: " + response)
    return "Success"

def ToUpper():
    response = helpers.getJsonFromURL(helpers.fetchURL('toupper', 'test,%20test'))
    expected = '{"string": "test, test in uppercase is TEST, TEST", "answer": "TEST, TEST", "status": 200}'
    if(expected != response):
       return ("Failure, response was: " + response)
    return "Success"

def Charcount():
    response = helpers.getJsonFromURL(helpers.fetchURL('charcount', 'test,%20test'))
    expected = '{"error": false, "string": "Contains 10 characters", "status": 200, "answer": 10}'
    if(expected != response):
        return ("Failure, response was: " + response)
    return "Success"

def Wordcount():
    response = helpers.getJsonFromURL(helpers.fetchURL('wordcount', 'test,%20test'))
    expected = '{"error": false, "status": 200, "string": "Contains 2 words", "answer": 2}'
    if(expected != response):
        return ("Failure, response was: " + response)
    return "Success"

def Proxy():
    response = helpers.getJsonFromURL(helpers.fetchURL('proxy', '/test'))
    expected = '{"error": false, "status": 200, "answer": "Test Successful"}'
    if(expected != response):
        return ("Failure, response was: " + response)
    return "Success"