import json
import urllib
import metricTests
import time
from discord_webhook import DiscordWebhook
from datetime import datetime


 
def getJsonFromURL(url):
    try:
        response = urllib.request.urlopen(url)
        reply = json.loads(response.read())
        return json.dumps(reply)
    except BaseException:
        response = "404 Error"
        return response

def fetchURL(func, text):
    config_file = open('config.json')
    URL_list = json.load(config_file)
    return (URL_list[func] + text)

def buildReport():
        
    now = datetime.now()

    current_time = now.strftime("%H:%M:%S")
    x = 0
    start = time.time()
    vowelCountTest = metricTests.VowelCount()
    if vowelCountTest == "Success":
        x = x+1
    theReplacerTest = metricTests.TheReplacer()
    if theReplacerTest == "Success":
        x = x+1
    commaCounterTest = metricTests.CommaCount()
    if commaCounterTest == "Success":
        x = x+1
    toUpperTest = metricTests.ToUpper()
    if toUpperTest == "Success":
        x = x+1
    charcountTest = metricTests.Charcount()
    if charcountTest == "Success":
        x = x+1
    wordcountTest = metricTests.Wordcount()
    if wordcountTest == "Success":
        x = x+1
    proxyTest = metricTests.Proxy()
    if proxyTest == "Success":
        x = x+1
    end = time.time()
    score = str(x)
    timeTaken = (end - start)
    timeTaken = str(timeTaken)[0:5]
    outputstring = "Editoron3000 service check: \n"
    outputstring+= ("Time: " + current_time + "\n")
    outputstring+= ("Vowelcount: " + vowelCountTest + "\n")
    outputstring+= ("TheReplacer: " + theReplacerTest + "\n")
    outputstring+= ("ToUpper: " + toUpperTest + "\n")
    outputstring+= ("CommaCount: " + commaCounterTest + "\n")
    outputstring+= ("Wordcount: " + wordcountTest + "\n")
    outputstring+= ("Charcount: " + charcountTest + "\n")
    outputstring+= ("Proxy Router: " + proxyTest + "\n")
    outputstring+= (score + "/7 tests passed \n")
    outputstring+= ("Time Taken: "+timeTaken+"s \n")
    outputstring+= "Brought to you by Coca-Cola Zero Sugar \n"
    if x < 7:
        outputstring+= "@everyone Error has occured \n"
    return outputstring

def sendMetrics(metrics):
    webhook = DiscordWebhook(url='https://discord.com/api/webhooks/919273118168678440/ixPCDagBlt_G2eJkOmtrKhY7T3wcyjG1vm4a6CrtV_t_JtFf14_cWc_4YFR-8kpuhpTA', content=metrics)
    response = webhook.execute()