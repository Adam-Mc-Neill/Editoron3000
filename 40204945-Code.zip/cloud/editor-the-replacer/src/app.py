from flask import Flask
from flask import request
from flask import Response
import json
import lambda_function

app = Flask(__name__)

@app.route('/')

def theReplace():
  x = request.args.get("x")
  context = 'test'
  jsonr = {
    "queryStringParameters": {
    "x": x
    }
  }
  event = json.dumps(jsonr)
  reply = lambda_function.lambda_handler(event, context)
  eventS = json.loads(reply)
  response=Response(response=reply, status=int(eventS["status"]), mimetype='application/json')
  response.headers["Content-Type"]="application/json"
  response.headers["Access-Control-Allow-Origin"]="*"
  return response

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5001)
