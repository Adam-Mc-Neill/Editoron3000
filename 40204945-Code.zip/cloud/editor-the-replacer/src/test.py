import unittest
from flask import Flask
from app import app
from theReplacer import replaceThe

class testTheReplacer(unittest.TestCase):

    app.testing = True
    client = app.test_client()

    def test_replaceTheA(self):
        self.assertEqual(replaceThe("the cat"),"a cat")

    def test_replaceTheAn(self):
         self.assertEqual(replaceThe("the ardvark"),"an ardvark")

    def test_RejectsMissingParams(self):
        tester = app.test_client(self)
        response = tester.get('/', content_type='html/text')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.data, b'{"error": true, "status": 400, "mimetype": "application/json", "body": "You must provide a string", "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}}')
 

    def test_theReplaceRequest(self):
        tester = app.test_client(self)
        response = tester.get('/?x=the%20test', content_type='html/text')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"error": false, "status": 200, "mimetype": "application/json", "body": "a test", "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}}')

if __name__ == 'main':
    unittest.main()
