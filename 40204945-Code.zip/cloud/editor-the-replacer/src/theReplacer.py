
def replaceThe(string):
    words = string.split()
    for j in range(len(words)-1):
        print(words[j])
        if words[j] == "the" or words[j] == "The":
            i = words[j+1]
            if i[0] == 'a' or i == 'e' or i == 'i' or i == 'o' or i == 'u' or i == 'A' or i == 'E' or i == 'I' or i == 'O' or i == 'U':
                words[j] = "an"
            else:
                words[j] = "a"
    sentence = " ".join(words)
    return sentence
