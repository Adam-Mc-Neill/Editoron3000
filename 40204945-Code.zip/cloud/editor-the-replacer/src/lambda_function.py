import json
import theReplacer

def lambda_handler(event, context):
    # TODO implement
    eventS = json.loads(event)
    print(eventS["queryStringParameters"]["x"] ,"event HERE")
    if eventS["queryStringParameters"]["x"] is None:
        msg = "You must provide a string"
        Response = json.dumps(response(True, 400, msg))
        return Response
    x = eventS["queryStringParameters"]["x"]
    print(x, "this is what x is getting picked up as")
    answer = theReplacer.replaceThe(x)
    Response = json.dumps(response(False, 200, answer))
    return Response

def response(error, status_code, message):
    return {
        'error': error,
        'status': status_code,
        'mimetype': 'application/json',
        'body': message,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        }
    }
