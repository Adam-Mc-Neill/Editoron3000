# editor-the-replacer

Should replace instances of the word "the" with "a" or "an" based on whether the following word begins with a vowel or not