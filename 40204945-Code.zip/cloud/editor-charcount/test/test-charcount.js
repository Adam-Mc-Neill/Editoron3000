var expect  = require('chai').expect;
const request = require('request');
var charcount = require('../charcount');

it('Char Count Test', function(done) {
        var t = 'hello world';
        var a = t.length;
        expect(charcount.counter(t)).to.equal(a);
        done();
});

describe("Charcount API", function() {

        describe("No parameter to count", function() {

                var url = "http://localhost:80/";

                it("returns status 400", function(done) {
                        request(url, function(error, response, body) {
                                console.log(body);
                                const j = JSON.parse(body);
                        expect(j.status).to.equal(400);
                        done();
                        });
                });
                it("returns error as true", function(done) {
                        request(url, function(error, response, body) {
                                console.log(body);
                                const j = JSON.parse(body);
                        expect(j.error).to.equal(true);
                        done();
                        });
                });
                it("returns error message", function(done) {
                        request(url, function(error, response, body) {
                                console.log(body);
                                const j = JSON.parse(body);
                        expect(j.string).to.equal('Please provide a string');
                        done();
                        });
                });
        });
        describe("successful test", function() {

                var url = "http://localhost:80/?x=test";

                it("returns status 200", function(done) {
                        request(url, function(error, response, body) {
                                console.log(body);
                                const j = JSON.parse(body);
                        expect(j.status).to.equal(200);
                        done();
                        });
                });
                it("returns error as false", function(done) {
                        request(url, function(error, response, body) {
                                console.log(body);
                                const j = JSON.parse(body);
                        expect(j.error).to.equal(false);
                        done();
                        });
                });
                it("returns correct message", function(done) {
                        request(url, function(error, response, body) {
                                console.log(body);
                                const j = JSON.parse(body);
                        expect(j.string).to.equal('Contains 4 characters');
                        done();
                        });
                });
        });
});
