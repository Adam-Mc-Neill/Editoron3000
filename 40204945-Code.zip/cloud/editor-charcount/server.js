'use strict';

const express = require('express');

const PORT = 80;
const HOST = '0.0.0.0';

var charcount = require('./charcount');

const app = express();
app.get('/', (req,res) => {

    var output = {
        'error': false,
        'string': '',
        'status': 0,
        'answer': 0
    };

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Access-Control-Allow-Origin', '*')
    var x = req.query.x;
    if (x !== undefined)
    {
        var answer = charcount.counter(x);

        output.string = 'Contains '+answer+ ' characters';
        output.status = 200;
        output.answer = answer;
    
        res.end(JSON.stringify(output));
    }
    else
    {
        output.error = true
        output.string = 'Please provide a string';
        output.status = 400;
    
        res.end(JSON.stringify(output));
    }
    
});

app.listen(PORT, HOST);
