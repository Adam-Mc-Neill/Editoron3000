<?php
header("Access-Control-Allow-Origin: *");
header("Content-type: application/json");
require('functions.inc.php');


$output = array(
	"error" => false,
	"status" => 200,
	"string" => "",
	"answer" => 0
);

$x = $_REQUEST['x'];

if (!isset($x)){
	$outputError = array(
		"error" => true,
		"status" => 400,
		"string" => "Please provide a string",
		"answer" => 0
	);
	echo json_encode($outputError);
	exit();
}

$answer=wordcount($x);

$output['string']="Contains ".$answer." words";
$output['answer']=$answer;

echo json_encode($output);
exit();
