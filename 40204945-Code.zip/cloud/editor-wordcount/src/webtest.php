<?php
echo "Test Script Starting\n";
require('index.php');

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "http://localhost:2000/?x=test");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1) ;
curl_setopt($ch, CURLOPT_HEADER, 0) ;

$server_output = curl_exec($ch);

$myJSON = json_decode($server_output);

$error = $myJSON->error;
$answer = $myJSON->answer;

echo "Test No error should be returned n";
if ($error==false)
{
    echo "Test Passed\n";
}
else
{
    echo "Test Failed\n";
    exit(1); // exit code not zero - error
}
echo "Test Correct answer should be returned n";
if ($answer==1)
{
    echo "Test Passed\n";
    exit(0); // exit code not zero - error
}
else
{
    echo "Test Failed\n";
    exit(1); // exit code not zero - error
}