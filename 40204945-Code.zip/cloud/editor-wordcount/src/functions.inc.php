<?php
// get count of words - no error checking
function wordcount($x)
{
    return str_word_count($x);
}