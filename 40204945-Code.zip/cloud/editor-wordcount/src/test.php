<?php
echo "Test Script Starting\n";
require('functions.inc.php');

$x="there are four words";
$expect=4;

$answer=wordcount($x);

echo "Test Result: '".$x."'=".$answer." (expected: ".$expect.")\n";

if ($answer==$expect)
{
    echo "Test Passed\n";
    exit(0); // exit code 0 - success
}
else
{
    echo "Test Failed\n";
    exit(1); // exit code not zero - error
}
