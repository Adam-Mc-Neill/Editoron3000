package main

import (
	"encoding/json"
	"net/http"
	"strconv"
)

type CustomResponse struct {
	Answer  int
	Error   bool
	Status  int
	Message string
}

func errorCheck(err error) {
	if err != nil {
		panic(err)
	}
}

func main() {
	http.HandleFunc("/", ServeHTTP)
	err := http.ListenAndServe("0.0.0.0:7000", nil)
	errorCheck(err)
}

type Entry struct{}

func ServeHTTP(wr http.ResponseWriter, r *http.Request) {
	x := r.URL.Query().Get("x")
	if x == "" {
		wr.Header().Set("Content-Type", "application/json")
		wr.Header().Set("Access-Control-Allow-Origin", "*")
		wr.WriteHeader(http.StatusBadGateway)
		b, err := json.Marshal(CustomResponse{Answer: -1, Error: true, Status: 400, Message: "Please Provide a string"})
		if err != nil {
			errorCheck(err)
		}
		wr.Write(b)
		return
	} else {
		answer := CommaCounter(x)
		wr.Header().Set("Content-Type", "application/json")
		wr.Header().Set("Access-Control-Allow-Origin", "*")
		wr.WriteHeader(http.StatusOK)
		str := strconv.Itoa(answer) + " commas in " + x
		b, err := json.Marshal(CustomResponse{Answer: answer, Error: false, Status: 200, Message: str})
		if err != nil {
			errorCheck(err)
		}
		wr.Write(b)
		return
	}

}
