package main

import (
	"strings"
)

func CommaCounter(x string) int {
	return strings.Count(x, ",")
}
