class ToUpper
    def self.upper (a)
        x = a.upcase
        return x
    end  
end