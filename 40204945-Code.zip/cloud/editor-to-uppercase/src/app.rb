#!/usr/bin/env ruby

require "webrick"
require 'json'
require './toUpper.rb'


class MyServlet < WEBrick::HTTPServlet::AbstractServlet
    def do_GET (request, response)
        response.content_type = "application/json"
        response.header['Access-Control-Allow-Origin'] = '*'
        if request.query["x"]
            x = request.query["x"]
            response.status = 200
            result = ToUpper.upper(x)
            raw_response = {
                "string" => x + " in uppercase is " + result,
                "answer" => result,
                "status" => 200
            }
            response.body = JSON.generate(raw_response)
        else
            response.status = 400
            error_response = {
                "string" => "Please provide a string",
                "answer" => "N/A",
                "status" => 400
            }
            response.body = JSON.generate(error_response)
        end
    end
end

server = WEBrick::HTTPServer.new(:Port => 1234)

server.mount "/", MyServlet

trap("INT") {
    server.shutdown
}

server.start