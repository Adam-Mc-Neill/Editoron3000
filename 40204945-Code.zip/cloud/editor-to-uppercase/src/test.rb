require 'test-unit'
require './toUpper.rb'

class UpperTest < Test::Unit::TestCase
    def test_upper
       x = ToUpper.upper('test') 
       assert_equal('TEST', x, "toUpper.upper should return the string passed to it in block capitals")
    end
  
end
