import unittest
from flask import Flask
from app import app
from buildURL import buildURL

class testVowelCount(unittest.TestCase):

    def test_buildURL(self):
        self.assertEqual(buildURL("vowelcount", "cool"),"http://vowelcount.40204945.qpc.hal.davecutting.uk/?x=cool")

    def test_buildURL_FaaS(self):
        self.assertEqual(buildURL("thereplacer", ""),"https://vlqo1kz9h2.execute-api.us-east-2.amazonaws.com/default/TheReplacer?x=")

    def test_CallVowelCount(self):
        tester = app.test_client(self)
        response = tester.get('/?func=vowelcount&text=cool', content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"error": false, "status": 200, "string": "cool contains 2 vowels.", "x": "cool", "answer": 2}')
    
    def test_CallTheReplacer(self):
        tester = app.test_client(self)
        response = tester.get('/?func=thereplacer&text=the cool', content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"error": false, "status": 200, "answer": "a cool", "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}}')
 
        
    def test_CallCommaCount(self):
        tester = app.test_client(self)
        response = tester.get('/?func=commacount&text=,,,', content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"Answer": 3, "Error": false, "Status": 200, "Message": "3 commas in ,,,"}')
    

    def test_CallToUpper(self):
        tester = app.test_client(self)
        response = tester.get('/?func=toupper&text=cool', content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"string": "cool in uppercase is COOL", "answer": "COOL"}')

    def test_CallCharcount(self):
        tester = app.test_client(self)
        response = tester.get('/?func=charcount&text=cool', content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"error": false, "string": "Contains 4 characters", "status": 200, "answer": 4}')

    def test_CallWordcount(self):
        tester = app.test_client(self)
        response = tester.get('/?func=wordcount&text=cool', content_type='application/json')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b'{"error": false, "string": "Contains 1 words", "answer": 1}')