import json

def buildURL(func, text):

    config_file = open('config.json')
    URL_list = json.load(config_file)
    if func == 'metrics':
        return URL_list['metrics']
    return URL_list[func] + text
